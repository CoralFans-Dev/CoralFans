#pragma once

#include "mc/world/actor/player/Player.h"
#include "mc/world/level/BlockPos.h"

namespace coral_fans::functions {

void rotateBlock(Player*, BlockPos);

}