namespace coral_fans::functions {
void hook_portal_sand_farm(bool);
} // namespace coral_fans::functions