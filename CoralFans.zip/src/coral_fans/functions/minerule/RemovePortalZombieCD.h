namespace coral_fans::functions {
void portal_spawn_hook(bool);
} // namespace coral_fans::functions