#include "mc/util/Randomize.h"
#include "mc/world/level/block/ResourceDropsContext.h"


namespace coral_fans::functions {

void bedrockDropHook(bool);
void mbDropHook(bool);
} // namespace coral_fans::functions