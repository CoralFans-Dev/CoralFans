#pragma once

namespace coral_fans::functions {

void registerShortcutsListener();
void registerShortcutsCommand();

} // namespace coral_fans::functions