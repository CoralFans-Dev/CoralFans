#pragma once

namespace coral_fans::functions {

void registerContainerReader();

} // namespace coral_fans::functions