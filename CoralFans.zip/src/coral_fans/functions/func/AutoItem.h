#pragma once

namespace coral_fans::functions {

void registerAutoItemListener();

}