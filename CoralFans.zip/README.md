# CoralFans

CoralFans Mod.

## Install

+ Use lip

```bash
lip install github.com/CoralFans-Dev/CoralFans
```

## Usage

+ See [doc-page](https://coralfans-dev.github.io/CoralFans-doc/) for more info.

## Contributing

Ask questions by creating an issue.

PRs accepted.

## Acknowledgement

+ [@OEOTYAN](https://github.com/OEOTYAN) (Partial source code provided)
+ [trapdoor-ll](https://github.com/bedrock-dev/trapdoor-ll) (Partial source code provided)

## License

AGPL v3 License
